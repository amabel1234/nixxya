import React, { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListOpenaiConversations,
  useCreateOpenaiConversation,
  useDeleteOpenaiConversation,
  getListOpenaiConversationsQueryKey,
  getGetOpenaiConversationQueryKey,
  getListOpenaiMessagesQueryKey,
} from "@workspace/api-client-react";
import { useTheme } from "@/App";
import ChatSidebar from "@/components/chat-sidebar";
import ChatThread from "@/components/chat-thread";

const MODELS = [
  { id: "deepseekv3", label: "Nixx AI",       badge: "Fast",     icon: "🧠", off: false },
  { id: "christyai",  label: "Christy AI",    badge: "JKT48",    icon: "⭐", off: false },
  { id: "copilot",    label: "Copilot AI",    badge: "Microsoft",icon: "🤖", off: false },
  { id: "ripple",     label: "Ripple AI",     badge: "OFF",      icon: "🌊", off: true  },
  { id: "felo",       label: "Felo AI",       badge: "New",      icon: "🔍", off: false },
  { id: "turboseek",  label: "Turboseek AI",  badge: "Fast",     icon: "🚀", off: false },
  { id: "perplexed",  label: "Perplexed AI",  badge: "Advanced", icon: "❓", off: false },
  { id: "muslim",     label: "Muslim AI",     badge: "Religious",icon: "🕌", off: false },
  { id: "gpt3",       label: "GPT-3",         badge: "OpenAI",   icon: "🤖", off: false },
  { id: "gpt4o",      label: "GPT-4o",        badge: "Latest",   icon: "🤖", off: false },
  { id: "perplexity", label: "Perplexity AI", badge: "Web",      icon: "🔍", off: false },
  { id: "groqmini",   label: "Groq Mini",     badge: "Fast",     icon: "⚡", off: false },
  { id: "llama4",     label: "Llama-4 Scout", badge: "17B",      icon: "💻", off: false },
  { id: "llama33",    label: "Llama-3.3",     badge: "70B",      icon: "🌿", off: false },
  { id: "gemma",      label: "Gemma 7B",      badge: "Light",    icon: "💎", off: false },
  { id: "mistral",    label: "Mistral 7B",    badge: "v0.1",     icon: "🌬️", off: false },
  { id: "aoyo",       label: "Aoyo AI",       badge: "New",      icon: "💬", off: false },
  { id: "gptoss120",  label: "GPT-OSS 120B",  badge: "120B",     icon: "💻", off: false },
  { id: "gptoss20",   label: "GPT-OSS 20B",   badge: "20B",      icon: "💻", off: false },
  { id: "gemini25v1", label: "Gemini 2.5 v1", badge: "Flash",    icon: "🤖", off: false },
  { id: "gemini25v2", label: "Gemini 2.5 v2", badge: "Flash",    icon: "🤖", off: false },
  { id: "grok4fast",  label: "Grok 4 Fast",   badge: "Fast",     icon: "⚡", off: false },
  { id: "grok3mini",  label: "Grok 3 Mini",   badge: "Mini",     icon: "⚡", off: false },
  { id: "grok3jail1", label: "Grok Jail v1",  badge: "JB",       icon: "🔓", off: false },
  { id: "grok3jail2", label: "Grok Jail v2",  badge: "JB",       icon: "🔓", off: false },
  { id: "venice",     label: "Venice AI",     badge: "New",      icon: "🌊", off: false },
];

export { MODELS };

export default function ChatPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeConvId, setActiveConvId] = useState<number | null>(null);
  const [selectedModel, setSelectedModel] = useState("deepseekv3");

  const { isDark, toggle: toggleTheme } = useTheme();
  const queryClient = useQueryClient();

  const { data: conversations = [] } = useListOpenaiConversations();
  const createConversation = useCreateOpenaiConversation();
  const deleteConversation = useDeleteOpenaiConversation();

  const handleNewChat = () => {
    const activeModel = MODELS.find((m) => m.id === selectedModel);
    createConversation.mutate(
      { data: { title: `Percakapan Baru — ${activeModel?.label ?? "Nixx AI"}` } },
      {
        onSuccess: (newConv) => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          setActiveConvId(newConv.id);
          setSidebarOpen(false);
        },
      }
    );
  };

  const handleDelete = (id: number) => {
    deleteConversation.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          if (activeConvId === id) setActiveConvId(null);
        },
      }
    );
  };

  const handleClearChat = () => {
    if (!activeConvId) return;
    if (confirm("Hapus percakapan ini?")) {
      handleDelete(activeConvId);
    }
  };

  const handleSelectModel = (modelId: string) => {
    setSelectedModel(modelId);
    setSidebarOpen(false);
  };

  return (
    <>
      {/* Floating menu toggle */}
      <button
        className="nx-menu-toggle"
        onClick={() => setSidebarOpen((v) => !v)}
        data-testid="button-menu-toggle"
        aria-label="Buka sidebar"
      >
        ☰
      </button>

      {/* Floating theme toggle */}
      <button
        className="nx-theme-toggle"
        onClick={toggleTheme}
        data-testid="button-theme-toggle"
        aria-label="Toggle tema"
      >
        {isDark ? "☀️" : "🌙"}
      </button>

      {/* Sidebar overlay */}
      <div
        className={`nx-sidebar-overlay ${sidebarOpen ? "active" : ""}`}
        onClick={() => setSidebarOpen(false)}
      />

      {/* Sidebar */}
      <div className={`nx-sidebar ${sidebarOpen ? "active" : ""}`}>
        <ChatSidebar
          conversations={conversations}
          activeId={activeConvId}
          selectedModel={selectedModel}
          models={MODELS}
          onSelect={(id) => { setActiveConvId(id); setSidebarOpen(false); }}
          onNewChat={handleNewChat}
          onDelete={handleDelete}
          onClearChat={handleClearChat}
          onSelectModel={handleSelectModel}
        />
      </div>

      {/* Main card */}
      <div className="nx-main">
        {/* Header */}
        <header className="nx-header">
          <div className="nx-logo-container">
            <img
              src="https://iili.io/f7nDq8X.jpg"
              alt="Nixx AI"
              className="nx-logo-img"
              onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
            />
            <div className="nx-logo-text">
              <div className="nx-logo">Nixx AI</div>
              <div className="nx-tagline">26 AI Models • Free Assistant</div>
            </div>
          </div>
        </header>

        {/* Chat area */}
        <div className="nx-chat-container">
          {activeConvId ? (
            <ChatThread
              conversationId={activeConvId}
              selectedModel={selectedModel}
            />
          ) : (
            <div
              className="nx-chat-messages"
              style={{ justifyContent: "center", alignItems: "center", display: "flex", flexDirection: "column", gap: "16px" }}
            >
              <div className="nx-ai-msg nx-message" style={{ maxWidth: "90%", alignSelf: "auto" }}>
                <div className="nx-msg-content">
                  Halo! Saya Nixx AI dengan 26 model berbeda. Pilih model AI dari sidebar lalu mulai percakapan baru!
                </div>
              </div>
              <button
                className="nx-send-btn"
                style={{ minWidth: 180 }}
                onClick={handleNewChat}
                data-testid="button-start-chat"
              >
                + Percakapan Baru
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
